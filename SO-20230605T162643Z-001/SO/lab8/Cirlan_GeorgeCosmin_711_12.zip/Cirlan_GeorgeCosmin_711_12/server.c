/* server.c */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define BUF 4096

int numberOfLines(char *fileName)
{
    // Open received file
    fileName[strlen(fileName)-1] = '\0';
    FILE* file = fopen(fileName, "r");
    if (file == NULL)
    {
        perror("Error opening file");
        return -1;
    }
    // Read from file and count lines
    char text[BUF];
    int count = 0;
    while (fgets(text, BUF, file) != NULL)
        count++;
    return count;
}

int main (void)
{
    char puffer[BUF], puffer2[BUF], inhalt[BUF], response[BUF];
    char pid[6], responsePipe[BUF]; // For client pid and response pipe
    int r_fd, w_fd, n, i; // Pipe containing client pid
    int r_fd2; // Pipe containing the file name
    // Make all files to be created read-write for all users
    umask(0);
    if (mkfifo ("fifo1.1", O_RDWR | 0666) < 0)
    {
        // If pipe exits use it, otherwise create a new one. If fails, exit
        if(errno == EEXIST)
            printf ("Pipe already exits. Use it\n");
        else
        {
            perror("mkfifio()");
            exit (EXIT_FAILURE);
        }
    }
    // Read pipe, containing the message and the PID of client
    r_fd = open ("fifo1.1", O_RDONLY);
    r_fd2 = open ("fifo2.1", O_RDONLY);
    if (r_fd == -1 || r_fd2 == -1)
    {
        perror ("open(1)");
        exit (EXIT_FAILURE);
    }


    // Read PID and file name
    if (read (r_fd, puffer, BUF) != 0 && read (r_fd2, puffer2, BUF))
    {
        // Check how many lines the message has
        int nrLines = numberOfLines(puffer2);
        printf("\n");

        // Copy the PID of client and store it
        n = 0, i = 0;
        while (puffer[n] != '\n')
            pid[i++] = puffer[n++];
        pid[++i] = '\n';
        // Store in responsePipe the name of the FIFO to send the answer
        strcpy (responsePipe, "fifo.");
        strncat (responsePipe, pid, i);
        // Store in response the answer to send to client
        sprintf (response, "%d", nrLines);
        // Open responsePipe
        w_fd = open (responsePipe, O_WRONLY);
        if (w_fd == -1)
        {
            perror ("open(2)");
            exit (EXIT_FAILURE);
        }
        // Write response to pipe
        write (w_fd, response, sizeof(response));
        // Close pipes
        close (r_fd);
        close (r_fd2);
        close (w_fd);
    }
    return EXIT_SUCCESS;
}
