/* client.c */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define BUF 4096
int main (void) {
    char puffer[BUF], inhalt[BUF];
    int fd, fdx;
    int fd2;
    sprintf (puffer, "fifo.%d", getpid ());
    sprintf (inhalt, "%d\n", getpid ());
    // Make all files to be created read-write for all users
    umask(0);
    if (mkfifo (puffer, O_RDWR | 0666) < 0)
    {
        // If pipe exits use it, otherwise create a new one. If fails, exit
        if(errno == EEXIST)
            printf ("FIFO already exits. Use it\n");
        else
        {
            perror("mkfifio()");
            exit (EXIT_FAILURE);
        }
    }
    // Make fifo2 to send file name
    if (mkfifo ("fifo2.1", S_IRUSR | S_IWUSR) < 0)
    {
        // If pipe exits use it, otherwise create a new one. If fails, exit
        if(errno == EEXIST)
            printf ("FIFO2 already exits. Use it\n");
        else
        {
            perror("mkfifio2()");
            exit (EXIT_FAILURE);
        }
    }
    // Open pipes
    fd = open ("fifo1.1", O_WRONLY);
    fd2 = open("fifo2.1", O_WRONLY);
    // Response pipe
    fdx = open (puffer, O_RDWR);
    if (fd == -1 || fd2 == -1 || fdx == -1)
    {
        perror ("open()");
        exit (EXIT_FAILURE);
    }
    // Read until CTRL+D
    // Write to send pipe
    printf ("Write the message (End with CTRL+D)\n>>");
    if (fgets (puffer, BUF, stdin) != NULL)
    {
        write (fd, inhalt, BUF);
        write (fd2, puffer, BUF);
    }
    // Close pipes
    close(fd);
    close(fd2);
    // Get the answer and print it
    if (read (fdx, puffer, BUF))
    {
        printf("\nPrinting from client:");
        printf ("\nNumber of lines of the message: %s lines\n", puffer);
    }
    // Close pipes
    close(fdx);
    return EXIT_SUCCESS;
}